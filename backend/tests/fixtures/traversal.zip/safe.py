print('safe file')
